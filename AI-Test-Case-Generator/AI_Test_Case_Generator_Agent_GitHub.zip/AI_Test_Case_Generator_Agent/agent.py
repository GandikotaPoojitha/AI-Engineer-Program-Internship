from test_case_generator import generate_test_cases


def run_agent(requirement, model_name):
    if not requirement.strip():
        raise ValueError("Please enter a software requirement.")

    if len(requirement.strip()) < 15:
        raise ValueError("Please provide a more detailed requirement.")

    result = generate_test_cases(requirement, model_name)

    return result