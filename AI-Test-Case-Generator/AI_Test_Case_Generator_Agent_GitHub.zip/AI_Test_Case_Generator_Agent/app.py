import streamlit as st
import pandas as pd

from agent import run_agent
from database import (
    initialize_database,
    save_result,
    get_history,
    get_saved_result
)
from export_utils import export_to_csv


st.set_page_config(
    page_title="AI Test Case Generator",
    page_icon="🧪",
    layout="wide"
)

initialize_database()

if "cases" not in st.session_state:
    st.session_state.cases = []

if "requirement" not in st.session_state:
    st.session_state.requirement = ""

if "details" not in st.session_state:
    st.session_state.details = {}

if "editor_version" not in st.session_state:
    st.session_state.editor_version = 0


st.title("🧪 AI Test Case Generator Agent")

st.write(
    "Generate, review, edit and export software test cases "
    "using Artificial Intelligence."
)

st.sidebar.title("⚙️ Settings")

model_name = st.sidebar.text_input(
    "Ollama Model",
    value="llama3.2"
)

st.sidebar.info("AI processing runs locally using Ollama.")

st.subheader("Enter Software Requirement")

requirement = st.text_area(
    "Describe your software feature:",
    placeholder="Example: A user should be able to login using email and password.",
    height=130
)

if st.button("🚀 Generate Test Cases", type="primary"):

    if not requirement.strip():
        st.warning("Please enter a software requirement.")

    else:
        try:
            with st.spinner("AI agent is analyzing your requirement..."):

                result = run_agent(requirement, model_name)

                st.session_state.cases = result["test_cases"]
                st.session_state.details = result
                st.session_state.requirement = requirement
                st.session_state.editor_version += 1

            st.success("Test cases generated successfully!")

        except Exception as e:
            st.error(f"Generation failed: {e}")


if st.session_state.cases:

    st.divider()

    st.subheader("Requirement Analysis")

    details = st.session_state.details

    st.write("**Identified Feature:**", details.get("feature"))
    st.write("**AI Understanding:**", details.get("understanding"))
    st.write("**Assumptions:**", details.get("assumptions", []))

    st.subheader("Generated Test Cases")

    df = pd.DataFrame(st.session_state.cases)

    edited_df = st.data_editor(
        df,
        num_rows="dynamic",
        use_container_width=True,
        key=f"editor_{st.session_state.editor_version}"
    )

    st.session_state.cases = edited_df.to_dict(
        orient="records"
    )

    col1, col2 = st.columns(2)

    with col1:
        if st.button("💾 Save Test Cases"):
            save_result(
                st.session_state.requirement,
                {
                    **st.session_state.details,
                    "test_cases": st.session_state.cases
                }
            )
            st.success("Test cases saved successfully!")

    with col2:
        csv_data = export_to_csv(st.session_state.cases)

        st.download_button(
            "📥 Download CSV",
            data=csv_data,
            file_name="generated_test_cases.csv",
            mime="text/csv"
        )


st.divider()

st.subheader("Previous Test Case History")

history = get_history()

if history:

    options = {
        f"#{row[0]} - {row[1][:60]} ({row[2]})": row[0]
        for row in history
    }

    selected = st.selectbox(
        "Select previous requirement",
        list(options.keys())
    )

    if st.button("Load Previous Results"):

        saved = get_saved_result(options[selected])

        if saved:
            st.session_state.cases = saved["test_cases"]
            st.session_state.details = saved
            st.session_state.requirement = next(
                row[1] for row in history
                if row[0] == options[selected]
            )
            st.session_state.editor_version += 1
            st.rerun()

else:
    st.info("No saved history available yet.")

st.caption("AI Test Case Generator Agent | Xpert Champs Internship Project")