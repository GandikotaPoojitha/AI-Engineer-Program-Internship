import sqlite3
import json

DB_NAME = "test_cases.db"


def get_connection():
    return sqlite3.connect(DB_NAME)


def initialize_database():
    with get_connection() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                requirement TEXT,
                result TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)


def save_result(requirement, result):
    with get_connection() as conn:
        conn.execute(
            "INSERT INTO history (requirement, result) VALUES (?, ?)",
            (requirement, json.dumps(result))
        )


def get_history():
    with get_connection() as conn:
        return conn.execute(
            "SELECT id, requirement, created_at FROM history ORDER BY id DESC"
        ).fetchall()


def get_saved_result(record_id):
    with get_connection() as conn:
        row = conn.execute(
            "SELECT result FROM history WHERE id = ?",
            (record_id,)
        ).fetchone()

    return json.loads(row[0]) if row else None