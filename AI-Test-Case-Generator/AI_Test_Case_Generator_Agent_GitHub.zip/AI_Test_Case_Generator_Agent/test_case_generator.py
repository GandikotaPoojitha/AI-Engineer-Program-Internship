import json
import re
from langchain_ollama import ChatOllama
from prompts import SYSTEM_PROMPT


def generate_test_cases(requirement, model_name):
    llm = ChatOllama(
        model=model_name,
        temperature=0
    )

    response = llm.invoke(
        SYSTEM_PROMPT +
        "\n\nSoftware Requirement:\n" + requirement
    )

    content = response.content.strip()

    content = re.sub(r"^```(?:json)?\s*", "", content)
    content = re.sub(r"\s*```$", "", content)

    try:
        data = json.loads(content)
    except json.JSONDecodeError:
        raise ValueError("AI returned invalid JSON. Please retry.")

    if not isinstance(data, dict):
        raise ValueError("Invalid AI response format.")

    cases = data.get("test_cases")

    if not isinstance(cases, list) or not cases:
        raise ValueError("No valid test cases generated.")

    required = [
        "scenario_type", "title", "preconditions",
        "steps", "test_data", "expected_result", "priority"
    ]

    priorities = ["High", "Medium", "Low"]
    scenarios = ["Positive", "Negative", "Edge Case"]

    validated = []

    for index, case in enumerate(cases, start=1):
        if not isinstance(case, dict):
            raise ValueError("Invalid test case structure.")

        for field in required:
            if field not in case or not case[field]:
                raise ValueError(f"Missing field: {field}")

        if case["priority"] not in priorities:
            raise ValueError("Invalid priority received.")

        if case["scenario_type"] not in scenarios:
            raise ValueError("Invalid scenario type received.")

        if not isinstance(case["steps"], list):
            raise ValueError("Test steps must be a list.")

        validated.append({
            "ID": f"TC-{index:03}",
            "Scenario": case["scenario_type"],
            "Title": str(case["title"]),
            "Preconditions": str(case["preconditions"]),
            "Steps": "\n".join(map(str, case["steps"])),
            "Test Data": str(case["test_data"]),
            "Expected Result": str(case["expected_result"]),
            "Priority": case["priority"]
        })

    return {
        "feature": str(data.get("feature", "Not specified")),
        "understanding": str(data.get("understanding", "")),
        "assumptions": data.get("assumptions", []),
        "test_cases": validated
    }