
import os
from dotenv import load_dotenv
from google import genai

# Load the API key from the .env file
load_dotenv()

API_KEY = os.getenv("GEMINI_API_KEY")

if not API_KEY:
    raise ValueError(
        "Gemini API key not found. Check your .env file."
    )

# Connect to Gemini
client = genai.Client(api_key=API_KEY)

MODEL = "gemini-3.8-flash"


def compare_documents(text1, text2):
    """Summarize and compare two documents using AI."""

    prompt = f"""
    You are an AI Document Comparison Assistant.

    Analyze the two documents provided below.

    DOCUMENT 1:
    {text1}

    DOCUMENT 2:
    {text2}

    Give your answer using these sections:

    1. SUMMARY OF DOCUMENT 1
    Summarize its main purpose and important details.

    2. SUMMARY OF DOCUMENT 2
    Summarize its main purpose and important details.

    3. SIMILARITIES
    List the important information shared by both documents.

    4. DIFFERENCES
    Identify changes in dates, times, amounts, names,
    deadlines, requirements, and other important details.

    5. FINAL CONCLUSION
    Explain the most important changes.

    Rules:
    - Use only information from the provided documents.
    - Never invent facts or differences.
    - Clearly state when information is missing.
    - If a detail is unchanged, identify it as unchanged.
    - Use clear, simple English.
    """

    
    response = client.interactions.create(
    model=MODEL,
    input=prompt,
    timeout=120000
    )

    if not response.output_text:
         raise RuntimeError("Gemini returned an empty response.")

    return response.output_text

