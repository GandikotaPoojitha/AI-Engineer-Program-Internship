
import streamlit as st
from pdf_processor import extract_text
from ai_comparator import compare_documents
from report_generator import generate_pdf_report
st.set_page_config(
    page_title="AI Document Comparison Assistant",
    page_icon="📄",
    layout="wide"
)

st.title("AI Document Comparison Assistant")
st.write("Upload two PDF documents to summarize and compare them.")

col1, col2 = st.columns(2)

with col1:
    pdf1 = st.file_uploader(
        "Upload Document 1",
        type=["pdf"],
        key="pdf1"
    )

with col2:
    pdf2 = st.file_uploader(
        "Upload Document 2",
        type=["pdf"],
        key="pdf2"
    )

if st.button("Compare Documents", type="primary"):
    if pdf1 is None or pdf2 is None:
        st.warning("Please upload both PDF documents.")

    else:
        try:
            with st.spinner("Extracting PDF text..."):
                text1 = extract_text(pdf1)
                text2 = extract_text(pdf2)

            with st.spinner("Gemini is comparing the documents..."):
                result = compare_documents(text1, text2)

            st.success("Comparison completed successfully!")

            st.subheader("AI Comparison Report")
            st.markdown(result)

            st.download_button(
                label="Download Comparison as TXT",
                data=result,
                file_name="document_comparison.txt",
                mime="text/plain"
            )
            pdf_report = generate_pdf_report(result)

            st.download_button(
                label="Download Comparison as PDF",
                data=pdf_report,
                file_name="document_comparison_report.pdf",
                mime="application/pdf"
            )

        except Exception as error:
            st.error(f"Something went wrong: {error}")
