
from pypdf import PdfReader
from io import BytesIO


def extract_text(pdf_file):
    """Extract text from an uploaded PDF file."""

    reader = PdfReader(BytesIO(pdf_file.getvalue()))
    extracted_text = ""

    for page_number, page in enumerate(reader.pages, start=1):
        page_text = page.extract_text() or ""
        extracted_text += f"\n--- Page {page_number} ---\n"
        extracted_text += page_text

    if not extracted_text.strip():
        raise ValueError("No readable text found in this PDF.")

    return extracted_text
