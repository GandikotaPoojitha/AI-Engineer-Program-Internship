
from io import BytesIO
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.platypus import (
    SimpleDocTemplate,
    Paragraph,
    Spacer,
    Preformatted
)


def generate_pdf_report(comparison_text):
    """Create a downloadable PDF comparison report."""

    buffer = BytesIO()

    document = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        rightMargin=2 * cm,
        leftMargin=2 * cm,
        topMargin=2 * cm,
        bottomMargin=2 * cm
    )

    styles = getSampleStyleSheet()

    title_style = ParagraphStyle(
        "ReportTitle",
        parent=styles["Title"],
        textColor=colors.HexColor("#174A7E"),
        alignment=TA_CENTER,
        spaceAfter=20
    )

    heading_style = ParagraphStyle(
        "ReportHeading",
        parent=styles["Heading2"],
        textColor=colors.HexColor("#174A7E"),
        spaceBefore=12,
        spaceAfter=6
    )

    body_style = styles["BodyText"]
    story = []

    story.append(
        Paragraph("AI Document Comparison Report", title_style)
    )
    story.append(Spacer(1, 10))

    for line in comparison_text.splitlines():
        cleaned_line = line.strip()

        if not cleaned_line:
            story.append(Spacer(1, 6))
        elif (
            cleaned_line.isupper()
            and len(cleaned_line) < 100
        ):
            story.append(
                Paragraph(escape(cleaned_line), heading_style)
            )
        else:
            story.append(
                Paragraph(escape(cleaned_line), body_style)
            )

    document.build(story)

    buffer.seek(0)
    return buffer.getvalue()
