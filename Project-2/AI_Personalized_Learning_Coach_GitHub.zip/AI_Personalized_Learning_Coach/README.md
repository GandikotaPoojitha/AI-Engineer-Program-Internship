
# AI Personalized Learning Coach

## Project Overview

AI Personalized Learning Coach is an intelligent web application that creates personalized learning plans based on a learner's goals, current knowledge level, available study time, and quiz performance.

The application uses Generative AI to generate study plans and topic-based quizzes. It evaluates quiz answers, identifies topics that need improvement, and tracks learning progress.

## Technologies Used

- Python
- Streamlit
- Google Gemini API
- SQLite
- Pandas
- Plotly
- Python-dotenv

## Features

1. Learner Profile Creation
2. AI-Generated Personalized Study Plans
3. Day-wise Learning Objectives
4. Topic-Based MCQ Quiz Generation
5. Automatic Quiz Evaluation
6. Answer Explanations
7. Weak Topic Identification
8. Personalized Revision Recommendations
9. Progress Dashboard
10. SQLite Database Storage

## Project Structure

AI_Personalized_Learning_Coach/

- app.py
- ai_service.py
- learning_plan.py
- quiz_manager.py
- database.py
- requirements.txt
- .env.example
- README.md
- sample_data/

## Installation

Clone the repository:

    git clone YOUR_GITHUB_REPOSITORY_URL

Navigate into the project folder:

    cd AI_Personalized_Learning_Coach

Create a virtual environment:

    python -m venv venv

Activate it on Windows PowerShell:

    venv\Scripts\activate

Install dependencies:

    pip install -r requirements.txt

## API Configuration

Create a `.env` file in the project folder.

Add your Gemini API key:

    GEMINI_API_KEY=your_actual_api_key

Never upload your real API key to GitHub.

## Run the Application

    streamlit run app.py

Open the local URL displayed in your terminal.

## Database

The application uses SQLite to store:

- Learner profiles
- Generated study plans
- Quiz attempts
- Topic-wise progress

## Future Enhancements

- AI-powered adaptive learning recommendations
- Learning streak tracking
- More quiz question types
- Exportable progress reports
- Personalized revision schedules

## Conclusion

AI Personalized Learning Coach helps learners organize their studies, evaluate their knowledge, identify weak areas, and improve their learning experience through Generative AI.
