
import os
import json
import time
from dotenv import load_dotenv
from google import genai
from google.genai import types

load_dotenv()

MODEL_NAME = "gemini-3.8-flash"


def generate_study_plan(student_data):

    api_key = os.getenv("GEMINI_API_KEY")

    if not api_key:
        raise ValueError("Gemini API key missing in .env")

    client = genai.Client(
        api_key=api_key,
        http_options=types.HttpOptions(timeout=120000)
    )

    subject = student_data["subject"]
    goal = student_data["goal"]
    level = student_data["level"]
    duration = int(student_data["duration"])

    study_time = int(
        student_data.get(
            "daily_study_time",
            student_data.get("study_time", 60)
        )
    )

    prompt = f"""
    Create a practical {duration}-day learning plan.

    Subject: {subject}
    Goal: {goal}
    Level: {level}
    Daily study time: {study_time} minutes.

    Return JSON only:
    {{
      "plan": [
        {{
          "day": 1,
          "topic": "Topic",
          "objective": "Learning objective",
          "duration_minutes": 45,
          "activities": ["Learn concepts", "Practice questions"]
        }}
      ]
    }}

    Generate exactly {duration} days.
    Keep the plan concise and practical.
    """

    for attempt in range(2):
        try:
            response = client.models.generate_content(
                model=MODEL_NAME,
                contents=prompt,
                config=types.GenerateContentConfig(
                    response_mime_type="application/json",
                    max_output_tokens=3000,
                    temperature=0.4
                )
            )

            result = json.loads(response.text)

            if (
                "plan" not in result
                or len(result["plan"]) != duration
            ):
                raise ValueError("Incomplete study plan received.")

            return result

        except Exception as error:
            if attempt == 1:
                raise Exception(f"Gemini error: {error}")

            time.sleep(2)
