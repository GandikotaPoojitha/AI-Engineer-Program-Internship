
import streamlit as st
import pandas as pd
import plotly.express as px

from recommendation import generate_recommendations
from ai_service import generate_study_plan
from quiz_manager import generate_quiz, evaluate_answers

from database import (
    init_db,
    save_learner_and_plan,
    save_quiz_attempt,
    get_study_plan,
    get_quiz_history,
    get_topic_progress,
    get_all_learners,
    get_learner,
    update_topic_completion,
    get_completed_topics,
    get_study_completion_summary
)

# =====================================
# CONFIGURATION
# =====================================

st.set_page_config(
    page_title="AI Personalized Learning Coach",
    page_icon="🎓",
    layout="wide"
)

init_db()

st.title("🎓 AI Personalized Learning Coach")
st.write("Your intelligent AI-powered personal learning assistant.")

# Session state
defaults = {
    "active_learner_id": None,
    "quiz_questions": None,
    "quiz_topic": None,
    "quiz_result": None,
    "quiz_version": 0,
    "ai_recommendations": None
}

for key, value in defaults.items():
    if key not in st.session_state:
        st.session_state[key] = value


# =====================================
# LEARNER PROFILE SELECTION
# =====================================

learners = get_all_learners()

st.sidebar.title("👤 Learner Profiles")

if learners:

    learner_ids = [item["id"] for item in learners]

    current_id = st.session_state.active_learner_id

    if current_id not in learner_ids:
        current_id = learner_ids[0]

    def learner_label(learner_id):
        for item in learners:
            if item["id"] == learner_id:
                return f"{item['subject']} - Profile {learner_id}"
        return f"Profile {learner_id}"

    selected_id = st.sidebar.selectbox(
        "Select Profile",
        learner_ids,
        index=learner_ids.index(current_id),
        format_func=learner_label
    )

    if selected_id != st.session_state.active_learner_id:
        st.session_state.active_learner_id = selected_id
        st.session_state.quiz_questions = None
        st.session_state.quiz_result = None
        st.session_state.ai_recommendations = None
        st.session_state.quiz_version += 1

else:
    selected_id = None


# =====================================
# CREATE LEARNER PROFILE
# =====================================

st.header("📝 Create Learning Profile")

with st.expander(
    "Enter Your Learning Details",
    expanded=not bool(learners)
):

    with st.form("profile_form"):

        subject = st.text_input("Subject")
        goal = st.text_area("Learning Goal")

        level = st.selectbox(
            "Current Knowledge Level",
            ["Beginner", "Intermediate", "Advanced"]
        )

        col1, col2 = st.columns(2)

        with col1:
            duration = st.number_input(
                "Learning Duration (Days)",
                min_value=1,
                max_value=90,
                value=7
            )

        with col2:
            study_time = st.number_input(
                "Daily Study Time (Minutes)",
                min_value=15,
                max_value=600,
                value=60
            )

        create = st.form_submit_button(
            "Generate My Study Plan",
            use_container_width=True
        )

        if create:

            if not subject.strip() or not goal.strip():
                st.error("Please enter subject and learning goal.")

            else:

                # Both names are included for compatibility
                student_data = {
                    "subject": subject.strip(),
                    "goal": goal.strip(),
                    "level": level,
                    "duration": int(duration),
                    "daily_study_time": int(study_time),
                    "study_time": int(study_time)
                }

                try:
                    with st.spinner(
                        "AI is generating your study plan..."
                    ):

                        plan = generate_study_plan(student_data)

                    new_id = save_learner_and_plan(
                        student_data,
                        plan
                    )

                    st.session_state.active_learner_id = new_id
                    st.session_state.quiz_questions = None
                    st.session_state.quiz_result = None
                    st.session_state.ai_recommendations = None
                    st.session_state.quiz_version += 1

                    st.success(
                        "Learning profile created successfully!"
                    )

                    st.rerun()

                except Exception as error:
                    st.error(f"Error: {error}")


# =====================================
# LOAD ACTIVE LEARNER
# =====================================

selected_id = st.session_state.active_learner_id

if selected_id is None:
    st.info("Create a learning profile to get started.")
    st.stop()

learner = get_learner(selected_id)

if learner is None:
    st.error("Learner profile not found.")
    st.stop()


# =====================================
# LEARNER OVERVIEW
# =====================================

st.divider()
st.header("👋 Learning Overview")

c1, c2, c3 = st.columns(3)

c1.metric("Subject", learner["subject"])
c2.metric("Level", learner["level"])
c3.metric("Duration", f"{learner['duration']} Days")

st.write("**Goal:**", learner["goal"])

daily_time = learner.get(
    "daily_study_time",
    learner.get("study_time", 60)
)

st.write("**Daily Study Time:**", daily_time, "minutes")


# =====================================
# PERSONALIZED STUDY PLAN
# =====================================

st.divider()
st.header("📅 Personalized Study Plan")

plan_data = get_study_plan(selected_id)
plan_items = []

if plan_data:

    plan_items = (
        plan_data.get("plan", [])
        if isinstance(plan_data, dict)
        else plan_data
    )

    saved_topics = get_completed_topics(selected_id)

    completed_days = {
        item["day"]: bool(item["is_completed"])
        for item in saved_topics
    }

    for day in plan_items:

        day_number = day.get("day")
        topic = day.get("topic", "Study Topic")

        is_completed = completed_days.get(day_number, False)

        with st.expander(f"Day {day_number}: {topic}"):

            st.write("**Objective:**", day.get("objective", ""))

            st.write(
                "**Duration:**",
                day.get("duration_minutes", 0),
                "minutes"
            )

            st.write("**Activities:**")

            for activity in day.get("activities", []):
                st.write("•", activity)

            checked = st.checkbox(
                "Mark topic as completed",
                value=is_completed,
                key=f"topic_{selected_id}_{day_number}"
            )

            if checked != is_completed:

                update_topic_completion(
                    selected_id,
                    day_number,
                    topic,
                    checked
                )

                st.rerun()

    summary = get_study_completion_summary(selected_id)

    st.subheader("📈 Study Completion")

    c1, c2, c3 = st.columns(3)

    c1.metric("Completed", summary["completed_topics"])
    c2.metric("Pending", summary["pending_topics"])
    c3.metric("Completion", f"{summary['percentage']:.1f}%")

    st.progress(summary["percentage"] / 100)

else:
    st.warning("No study plan available.")


# =====================================
# TOPIC-BASED QUIZ
# =====================================

st.divider()
st.header("🧠 Test Your Knowledge")

topics = [
    item.get("topic", "")
    for item in plan_items
    if item.get("topic")
]

if topics:

    chosen_topic = st.selectbox(
        "Select a topic",
        topics
    )

    custom_topic = st.text_input(
        "Or enter a custom topic (optional)"
    )

    quiz_topic = custom_topic.strip() or chosen_topic

else:
    quiz_topic = st.text_input("Enter quiz topic")


if st.button(
    "Generate 5 MCQ Questions",
    use_container_width=True
):

    if not quiz_topic.strip():
        st.warning("Enter a topic.")

    else:
        try:

            with st.spinner("Generating questions with Gemini AI..."):

                questions = generate_quiz(
                    learner["subject"],
                    quiz_topic,
                    learner["level"]
                )

            st.session_state.quiz_questions = questions
            st.session_state.quiz_topic = quiz_topic
            st.session_state.quiz_result = None
            st.session_state.quiz_version += 1

            st.rerun()

        except Exception as error:
            st.error(f"Quiz generation failed: {error}")


# =====================================
# QUIZ INTERFACE
# =====================================

if st.session_state.quiz_questions:

    questions = st.session_state.quiz_questions

    st.subheader(f"Quiz: {st.session_state.quiz_topic}")

    with st.form(
        f"quiz_{selected_id}_{st.session_state.quiz_version}"
    ):

        answers = {}

        for i, question in enumerate(questions):

            st.write(
                f"**Question {i + 1}: {question['question']}**"
            )

            answers[i] = st.radio(
                "Select your answer",
                question["options"],
                index=None,
                key=(
                    f"answer_{selected_id}_"
                    f"{st.session_state.quiz_version}_{i}"
                )
            )

            st.divider()

        submit = st.form_submit_button(
            "Submit Quiz",
            use_container_width=True
        )

        if submit:

            if any(value is None for value in answers.values()):

                st.warning("Answer all questions before submitting.")

            else:

                try:

                    result = evaluate_answers(
                        questions,
                        answers
                    )

                    save_quiz_attempt(
                        selected_id,
                        st.session_state.quiz_topic,
                        result
                    )

                    st.session_state.quiz_result = result

                    st.rerun()

                except Exception as error:
                    st.error(f"Evaluation error: {error}")


# =====================================
# QUIZ RESULTS
# =====================================

if st.session_state.quiz_result:

    result = st.session_state.quiz_result

    st.divider()
    st.header("📋 Quiz Results")

    c1, c2, c3 = st.columns(3)

    c1.metric("Score", f"{result['score']}/{result['total']}")
    c2.metric("Percentage", f"{result['percentage']:.1f}%")
    c3.metric("Correct Answers", result["score"])

    if result["percentage"] >= 80:
        st.success("Excellent! Keep maintaining your performance.")

    elif result["percentage"] >= 60:
        st.warning("Good effort. Practise more to improve.")

    else:
        st.error("This topic needs revision.")

    st.subheader("Answer Explanations")

    for i, answer in enumerate(result["results"]):

        if answer["is_correct"]:
            st.success(f"Question {i + 1}: Correct")
        else:
            st.error(f"Question {i + 1}: Incorrect")

        st.write("Your Answer:", answer["selected_answer"])
        st.write("Correct Answer:", answer["correct_answer"])
        st.write("Explanation:", answer["explanation"])


# =====================================
# PROGRESS DASHBOARD
# =====================================

st.divider()
st.header("📊 Progress Dashboard")

history = get_quiz_history(selected_id)
progress = get_topic_progress(selected_id)

summary = get_study_completion_summary(selected_id)

if history:

    df = pd.DataFrame(history)

    average = df["percentage"].mean()
    best = df["percentage"].max()

    c1, c2, c3, c4 = st.columns(4)

    c1.metric("Total Quizzes", len(df))
    c2.metric("Average Score", f"{average:.1f}%")
    c3.metric("Best Score", f"{best:.1f}%")
    c4.metric(
        "Study Completion",
        f"{summary['percentage']:.1f}%"
    )

    st.subheader("Quiz Performance Over Time")

    df = df.sort_values(
        ["attempted_at", "id"]
    ).reset_index(drop=True)

    df["Attempt"] = range(1, len(df) + 1)

    fig = px.line(
        df,
        x="Attempt",
        y="percentage",
        markers=True,
        title="Quiz Score Progress"
    )

    fig.update_layout(yaxis_range=[0, 100])

    st.plotly_chart(fig, use_container_width=True)

    if progress:

        progress_df = pd.DataFrame(progress)

        st.subheader("Topic-wise Performance")

        fig2 = px.bar(
            progress_df,
            x="topic",
            y="best_score",
            color="status",
            title="Best Score by Topic"
        )

        fig2.update_layout(yaxis_range=[0, 100])

        st.plotly_chart(fig2, use_container_width=True)

        st.subheader("🧠 Learning Recommendations")

        for _, item in progress_df.iterrows():

            score = item["best_score"]

            if score < 60:
                st.error(
                    f"{item['topic']}: {score:.1f}% – "
                    "Revise concepts and attempt another quiz."
                )

            elif score < 80:
                st.warning(
                    f"{item['topic']}: {score:.1f}% – "
                    "Practise more questions."
                )

            else:
                st.success(
                    f"{item['topic']}: {score:.1f}% – On track!"
                )

    st.subheader("Recent Quiz History")

    st.dataframe(
        df.sort_values("id", ascending=False)[
            [
                "topic",
                "score",
                "total",
                "percentage",
                "attempted_at"
            ]
        ],
        use_container_width=True,
        hide_index=True
    )

else:
    st.info(
        "Complete your first quiz to see performance analytics."
    )


# =====================================
# AI PERSONALIZED RECOMMENDATIONS
# =====================================

st.divider()
st.header("🤖 AI Personalized Recommendations")

if st.button(
    "Generate My Recommendations",
    use_container_width=True
):

    try:

        with st.spinner(
            "AI is analyzing your learning performance..."
        ):

            recommendations = generate_recommendations(
                learner,
                progress,
                summary
            )

        st.session_state.ai_recommendations = recommendations

    except Exception as error:
        st.error(f"Recommendation error: {error}")


if st.session_state.ai_recommendations:

    result = st.session_state.ai_recommendations

    st.info(
        result.get(
            "summary",
            "Keep learning consistently!"
        )
    )

    recommendation_items = result.get("recommendations", [])

    if recommendation_items:

        for item in recommendation_items:

            with st.expander(
                item.get("topic", "Recommended Topic")
            ):

                st.write(
                    "**Priority:**",
                    item.get("priority", "Medium")
                )

                st.write(
                    "**Reason:**",
                    item.get("reason", "")
                )

                st.write(
                    "**Recommended Action:**",
                    item.get("action", "")
                )

    else:
        st.info(
            "Complete some quizzes to receive personalized recommendations."
        )


# =====================================
# FOOTER
# =====================================

st.divider()

st.caption(
    "AI Personalized Learning Coach | "
    "Python | Streamlit | Gemini AI | SQLite"
)
