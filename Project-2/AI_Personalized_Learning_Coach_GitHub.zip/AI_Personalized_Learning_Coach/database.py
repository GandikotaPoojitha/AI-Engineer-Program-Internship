
import sqlite3
import json
from datetime import datetime

DB_NAME = "learning_coach.db"


def current_timestamp():
    return datetime.now().isoformat(timespec="seconds")


def get_connection():
    connection = sqlite3.connect(DB_NAME)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    return connection


def init_db():
    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS learners (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            subject TEXT NOT NULL,
            goal TEXT NOT NULL,
            level TEXT NOT NULL,
            duration INTEGER NOT NULL,
            daily_study_time INTEGER NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS study_plans (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            learner_id INTEGER NOT NULL,
            plan_data TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (learner_id) REFERENCES learners(id)
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS quiz_attempts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            learner_id INTEGER NOT NULL,
            topic TEXT NOT NULL,
            score INTEGER NOT NULL,
            total INTEGER NOT NULL,
            percentage REAL NOT NULL,
            answers_data TEXT,
            attempted_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (learner_id) REFERENCES learners(id)
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS topic_progress (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            learner_id INTEGER NOT NULL,
            topic TEXT NOT NULL,
            attempts INTEGER DEFAULT 0,
            best_score REAL DEFAULT 0,
            status TEXT DEFAULT 'Needs Revision',
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(learner_id, topic),
            FOREIGN KEY (learner_id) REFERENCES learners(id)
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS plan_topic_progress (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            learner_id INTEGER NOT NULL,
            day INTEGER NOT NULL,
            topic TEXT NOT NULL,
            is_completed INTEGER DEFAULT 0,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(learner_id, day),
            FOREIGN KEY (learner_id) REFERENCES learners(id)
        )
    """)

    connection.commit()
    connection.close()


def save_learner_and_plan(student_data, plan):
    connection = get_connection()
    cursor = connection.cursor()

    try:
        now = current_timestamp()

        cursor.execute("""
            INSERT INTO learners
            (subject, goal, level, duration, daily_study_time, created_at)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (
            student_data["subject"],
            student_data["goal"],
            student_data["level"],
            student_data["duration"],
            student_data.get(
                "daily_study_time",
                student_data.get("study_time", 60)
            ),
            now
        ))

        learner_id = cursor.lastrowid

        cursor.execute("""
            INSERT INTO study_plans
            (learner_id, plan_data, created_at)
            VALUES (?, ?, ?)
        """, (learner_id, json.dumps(plan), now))

        plan_items = plan.get("plan", []) if isinstance(plan, dict) else plan

        for item in plan_items:
            cursor.execute("""
                INSERT OR IGNORE INTO plan_topic_progress
                (learner_id, day, topic, updated_at)
                VALUES (?, ?, ?, ?)
            """, (
                learner_id,
                item.get("day"),
                item.get("topic", "Untitled Topic"),
                now
            ))

        connection.commit()
        return learner_id

    except Exception:
        connection.rollback()
        raise

    finally:
        connection.close()


def save_quiz_attempt(learner_id, topic, result):
    connection = get_connection()
    cursor = connection.cursor()

    try:
        now = current_timestamp()
        percentage = result["percentage"]

        if percentage < 60:
            status = "Needs Revision"
        elif percentage < 80:
            status = "Practice Recommended"
        else:
            status = "On Track"

        cursor.execute("""
            INSERT INTO quiz_attempts
            (learner_id, topic, score, total, percentage,
             answers_data, attempted_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            learner_id,
            topic,
            result["score"],
            result["total"],
            percentage,
            json.dumps(result["results"]),
            now
        ))

        cursor.execute("""
            INSERT INTO topic_progress
            (learner_id, topic, attempts, best_score, status, updated_at)
            VALUES (?, ?, 1, ?, ?, ?)
            ON CONFLICT(learner_id, topic)
            DO UPDATE SET
                attempts = topic_progress.attempts + 1,
                best_score = MAX(
                    topic_progress.best_score,
                    excluded.best_score
                ),
                status = excluded.status,
                updated_at = excluded.updated_at
        """, (
            learner_id,
            topic,
            percentage,
            status,
            now
        ))

        connection.commit()

    except Exception:
        connection.rollback()
        raise

    finally:
        connection.close()


def get_study_plan(learner_id):
    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute("""
        SELECT plan_data FROM study_plans
        WHERE learner_id = ?
        ORDER BY id DESC LIMIT 1
    """, (learner_id,))

    row = cursor.fetchone()
    connection.close()

    return json.loads(row["plan_data"]) if row else None


def get_quiz_history(learner_id):
    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute("""
        SELECT * FROM quiz_attempts
        WHERE learner_id = ?
        ORDER BY attempted_at DESC, id DESC
    """, (learner_id,))

    rows = cursor.fetchall()
    connection.close()

    return [dict(row) for row in rows]


def get_topic_progress(learner_id):
    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute("""
        SELECT * FROM topic_progress
        WHERE learner_id = ?
        ORDER BY updated_at DESC
    """, (learner_id,))

    rows = cursor.fetchall()
    connection.close()

    return [dict(row) for row in rows]


def get_learner(learner_id):
    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute(
        "SELECT * FROM learners WHERE id = ?",
        (learner_id,)
    )

    row = cursor.fetchone()
    connection.close()

    return dict(row) if row else None


def get_all_learners():
    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute("SELECT * FROM learners ORDER BY id DESC")

    rows = cursor.fetchall()
    connection.close()

    return [dict(row) for row in rows]


def update_topic_completion(learner_id, day, topic, is_completed):
    connection = get_connection()
    cursor = connection.cursor()

    try:
        now = current_timestamp()

        cursor.execute("""
            INSERT INTO plan_topic_progress
            (learner_id, day, topic, is_completed, updated_at)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(learner_id, day)
            DO UPDATE SET
                topic = excluded.topic,
                is_completed = excluded.is_completed,
                updated_at = excluded.updated_at
        """, (
            learner_id,
            day,
            topic,
            int(is_completed),
            now
        ))

        connection.commit()

    except Exception:
        connection.rollback()
        raise

    finally:
        connection.close()


def get_completed_topics(learner_id):
    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute("""
        SELECT day, topic, is_completed
        FROM plan_topic_progress
        WHERE learner_id = ?
        ORDER BY day
    """, (learner_id,))

    rows = cursor.fetchall()
    connection.close()

    return [dict(row) for row in rows]


def get_study_completion_summary(learner_id):
    connection = get_connection()
    cursor = connection.cursor()

    cursor.execute("""
        SELECT COUNT(*) AS total_topics,
               COALESCE(SUM(is_completed), 0) AS completed_topics
        FROM plan_topic_progress
        WHERE learner_id = ?
    """, (learner_id,))

    row = cursor.fetchone()
    connection.close()

    total = row["total_topics"]
    completed = row["completed_topics"]

    return {
        "total_topics": total,
        "completed_topics": completed,
        "pending_topics": total - completed,
        "percentage": (completed / total * 100) if total else 0
    }
