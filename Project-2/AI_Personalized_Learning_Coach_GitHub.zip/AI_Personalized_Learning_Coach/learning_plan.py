
def get_plan_topics(plan):
    """Extract all topics from a learning plan."""

    if isinstance(plan, dict):
        plan = plan.get("plan", [])

    return [
        day.get("topic", "Untitled Topic")
        for day in plan
    ]


def get_total_study_time(plan):
    """Calculate the total planned study time."""

    if isinstance(plan, dict):
        plan = plan.get("plan", [])

    total_minutes = sum(
        day.get("duration_minutes", 0)
        for day in plan
    )

    return total_minutes


def format_study_plan(plan):
    """Prepare a study plan summary."""

    if isinstance(plan, dict):
        plan = plan.get("plan", [])

    summary = []

    for day in plan:
        summary.append({
            "day": day.get("day"),
            "topic": day.get("topic"),
            "objective": day.get("objective"),
            "duration_minutes": day.get("duration_minutes"),
            "activities": day.get("activities", [])
        })

    return summary
