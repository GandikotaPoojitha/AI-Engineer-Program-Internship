
import os
import json
from google import genai
from dotenv import load_dotenv

load_dotenv()

API_KEY = os.getenv("GEMINI_API_KEY")


def generate_quiz(subject, topic, level):

    if not API_KEY:
        raise ValueError("Gemini API key not found.")

    client = genai.Client(api_key=API_KEY)

    prompt = f"""
    You are an expert educational quiz generator.

    Create exactly 5 multiple-choice questions.

    Subject: {subject}
    Topic: {topic}
    Student Level: {level}

    Requirements:
    1. Questions must be relevant to the selected topic.
    2. Each question must have exactly four options.
    3. Only one option must be correct.
    4. Questions should match the student's knowledge level.
    5. Include a clear explanation for every answer.
    6. Avoid duplicate questions.

    Return valid JSON in this structure:

    {{
        "questions": [
            {{
                "question": "What is Python?",
                "options": [
                    "Programming language",
                    "Operating system",
                    "Database",
                    "Web browser"
                ],
                "correct_answer": "Programming language",
                "explanation": "Python is a high-level programming language."
            }}
        ]
    }}
    """

    try:

        response = client.models.generate_content(
            model="gemini-flash-latest",
            contents=prompt,
            config={
                "response_mime_type": "application/json"
            }
        )

        if not response.text:
            raise ValueError("Empty response received from Gemini.")

        result = json.loads(response.text)

        if not isinstance(result, dict) or "questions" not in result:
            raise ValueError("Invalid quiz response.")

        questions = result["questions"]

        if not isinstance(questions, list) or len(questions) != 5:
            raise ValueError("Quiz must contain exactly five questions.")

        # Validate questions
        for question in questions:

            if not isinstance(question, dict):
                raise ValueError("Invalid question format.")

            required = [
                "question",
                "options",
                "correct_answer",
                "explanation"
            ]

            for field in required:
                if field not in question:
                    raise ValueError(f"Missing field: {field}")

            options = question["options"]

            if (
                not isinstance(options, list)
                or len(options) != 4
                or not all(isinstance(option, str) for option in options)
                or len(set(options)) != 4
            ):
                raise ValueError("Each question needs four unique options.")

            if question["correct_answer"] not in options:
                raise ValueError("Correct answer is not among the options.")

            if not isinstance(question["explanation"], str):
                raise ValueError("Invalid explanation.")

        return questions

    except Exception as e:

        raise Exception(f"Unable to generate quiz: {str(e)}") from e


def evaluate_answers(questions, submitted_answers):

    score = 0
    results = []

    for index, question in enumerate(questions):

        selected = submitted_answers[index]
        correct = question["correct_answer"]

        is_correct = selected == correct

        if is_correct:
            score += 1

        results.append({
            "question": question["question"],
            "selected_answer": selected,
            "correct_answer": correct,
            "is_correct": is_correct,
            "explanation": question["explanation"]
        })

    percentage = (score / len(questions)) * 100

    return {
        "score": score,
        "total": len(questions),
        "percentage": percentage,
        "results": results
    }
