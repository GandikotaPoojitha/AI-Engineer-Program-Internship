
import os
import json
from dotenv import load_dotenv
from google import genai
from google.genai import types

load_dotenv()

MODEL_NAME = "gemini-3.8-flash"


def generate_recommendations(learner, topic_progress, completion_summary):

    weak_topics = [
        item for item in topic_progress
        if item.get("best_score", 0) < 80
    ]

    if not weak_topics:
        return {
            "summary": "Excellent progress! Keep learning consistently.",
            "recommendations": []
        }

    api_key = os.getenv("GEMINI_API_KEY")

    if not api_key:
        return {
            "summary": "Continue improving your learning performance.",
            "recommendations": [
                {
                    "topic": item["topic"],
                    "priority": "High",
                    "reason": f"Your best score is {item.get('best_score', 0)}%.",
                    "action": "Revise the concepts and attempt another quiz."
                }
                for item in weak_topics[:5]
            ]
        }

    try:
        client = genai.Client(
            api_key=api_key,
            http_options=types.HttpOptions(timeout=30000)
        )

        prompt = f"""
        You are an AI Personalized Learning Coach.

        Learner Details:
        {json.dumps(learner)}

        Topic Performance:
        {json.dumps(topic_progress)}

        Study Completion:
        {json.dumps(completion_summary)}

        Identify weak topics and generate personalized recommendations.

        Give a maximum of 5 recommendations.
        Prioritize topics with low scores.

        Return valid JSON only:
        {{
            "summary": "Short learning progress summary",
            "recommendations": [
                {{
                    "topic": "Topic name",
                    "priority": "High",
                    "reason": "Why improvement is needed",
                    "action": "Specific action to improve"
                }}
            ]
        }}
        """

        response = client.models.generate_content(
            model=MODEL_NAME,
            contents=prompt,
            config=types.GenerateContentConfig(
                response_mime_type="application/json",
                max_output_tokens=2000,
                temperature=0.4
            )
        )

        if not response.text:
            raise ValueError("Gemini returned an empty response.")

        result = json.loads(response.text)

        if "summary" not in result or "recommendations" not in result:
            raise ValueError("Invalid recommendation response.")

        return result

    except Exception as error:
        return {
            "summary": "AI recommendations are temporarily unavailable.",
            "recommendations": [
                {
                    "topic": item["topic"],
                    "priority": "High",
                    "reason": f"Your best score is {item.get('best_score', 0)}%.",
                    "action": "Revise this topic and attempt another quiz."
                }
                for item in weak_topics[:5]
            ],
            "error": str(error)
        }
